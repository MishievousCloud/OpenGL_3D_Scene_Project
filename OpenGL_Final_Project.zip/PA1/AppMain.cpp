#include <GLEW/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>

// GLM Mathematics
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Texture libraries
#include <SOIL2\SOIL2.h>

using namespace std;

int width, height;
const double PI = 3.14159;
const float toRadians = PI / 180.0f;
float lightR = 1.0f;
float lightG = 1.0f;
float lightB = 1.0f;


// Input function prototype
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
void cursor_position_callback(GLFWwindow* window, double xpos, double ypos);

// Declare view matrix
glm::mat4 viewMatrix;

// Initialize FOV
GLfloat fov = 45.f;

// Define camera attributes
glm::vec3 cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 cameraDirection = glm::normalize(cameraPosition - cameraTarget);
glm::vec3 worldUp = glm::vec3(0.0f, 1.f, 0.0f);
glm::vec3 cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));
glm::vec3 cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight));
glm::vec3 cameraFront = glm::normalize(glm::vec3(0.0f, 0.0f, -1.0f));

// Get target prototype
glm::vec3 getTarget();

// Camera transformation prototype
void transformCamera();

// Boolean array for keys and mouse buttons
bool keys[1024], mouseButtons[3];

// Boolean to check camera transformation
bool isPanning = false, isOrbiting = false;

// Radius, Pitch, Yaw
GLfloat radius = 3.f, rawPitch = 0.f, rawYaw = 0.f, degPitch, degYaw;

GLfloat deltaTime = 0.f, lastFrame = 0.f;
GLfloat lastX = width / 2, lastY = height / 2, xChange, yChange;

// Check for initial mouse movement
bool firstMouseMove = true;

// Camera Reset
void initCamera();

// Input Control
void processInput(GLFWwindow* window);

// Light source position
glm::vec3 lightPosition(-0.7f, 1.9f, 2.2f);
glm::vec3 lightPosition2(2.5f, 1.2f, 5.0f); // For use later if a second light source is needed.

// Draw Primitive(s)
void draw()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 6;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

void draw2()
{
	GLenum mode = GL_TRIANGLES;
	GLsizei indices = 3;
	glDrawElements(mode, indices, GL_UNSIGNED_BYTE, nullptr);
}

// Create and Compile Shaders
static GLuint CompileShader(const string& source, GLuint shaderType)
{
	// Create Shader object
	GLuint shaderID = glCreateShader(shaderType);
	const char* src = source.c_str();

	// Attach source code to Shader object
	glShaderSource(shaderID, 1, &src, nullptr);

	// Compile Shader
	glCompileShader(shaderID);

	// Return ID of Compiled shader
	return shaderID;
}

// Create Program Object
static GLuint CreateShaderProgram(const string& vertexShader, const string& fragmentShader)
{
	// Compile vertex shader
	GLuint vertexShaderComp = CompileShader(vertexShader, GL_VERTEX_SHADER);

	// Compile fragment shader
	GLuint fragmentShaderComp = CompileShader(fragmentShader, GL_FRAGMENT_SHADER);

	// Create program object
	GLuint shaderProgram = glCreateProgram();

	// Attach vertex and fragment shaders to program object
	glAttachShader(shaderProgram, vertexShaderComp);
	glAttachShader(shaderProgram, fragmentShaderComp);

	// Link shaders to create executable
	glLinkProgram(shaderProgram);

	// Delete compiled vertex and fragment shaders
	glDeleteShader(vertexShaderComp);
	glDeleteShader(fragmentShaderComp);

	// Return Shader Program
	return shaderProgram;
}

int main(void)
{
	width = 640; height = 480;

	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(width, height, "Main Window", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	// Set input callback functions
	glfwSetKeyCallback(window, key_callback);
	glfwSetScrollCallback(window, scroll_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetCursorPosCallback(window, cursor_position_callback);

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	if (glewInit() != GLEW_OK)
		cout << "Error!" << endl;
	
	// Light Cube object coords
	GLfloat lampVertices[] = {
		-0.5, -0.5, 0.0,  // i0
		-0.5, 0.5, 0.0,   // i1
		0.5, -0.5, 0.0,   // i2
		0.5, 0.5, 0.0     // i3
	};

	// Plane type object indices. Utilized by multiple objects.
	GLubyte indices[] = {
		0, 1, 2,
		1, 2, 3
	};

	GLubyte indices2[] = {
		0, 1, 2
	};

	// Table object coords
	GLfloat tableVertices[] = {
		-4.0, -3.0, 0.0,  // i0
		1.0, 0.0, 0.5,    // RGB
		0.0, 0.0,         // UV map Bottom left
		0.0f, 0.0f, 1.0f, // normal +Z

		-4.0, 1.0, 0.0,   // i1
		1.0, 0.0, 0.5,    // RGB
		0.0, 1.0,		  // UV map Top left
		0.0f, 0.0f, 1.0f, // normal +Z

		4.0, -3.0, 0.0,   // i2
		1.0, 0.0, 0.5,    // RGB
		1.0, 0.0,		  // UV map Bottom right
		0.0f, 0.0f, 1.0f, // normal +Z

		4.0, 1.0, 0.0,    // i3
		1.0, 0.0, 0.5,    // RGB
		1.0, 1.0,		  // UV map Top right
		0.0f, 0.0f, 1.0f  // normal +Z
	};

	// plane Object coords
	GLfloat planeVertices[] = {
		-0.5, -0.5, 0.0,  // i0
		0.0, 1.0, 1.0,    // RGB
		0.0, 0.0,         // UV map Bottom left
		0.0f, 0.0f, 1.0f, // normal +Z

		-0.5, 0.5, 0.0,   // i1
		0.0, 1.0, 1.0,    // RGB
		0.0, 1.0,		  // UV map Top left
		0.0f, 0.0f, 1.0f, // normal +Z

		0.5, -0.5, 0.0,   // i2
		0.0, 1.0, 1.0,    // RGB
		1.0, 0.0,		  // UV map Bottom right
		0.0f, 0.0f, 1.0f, // normal +Z

		0.5, 0.5, 0.0,    // i3
		0.0, 1.0, 1.0,    // RGB
		1.0, 1.0,		  // UV map Top right
		0.0f, 0.0f, 1.0f  // normal +Z
	};

	// Tissue Object coords
	GLfloat tissueVertices[] = {
		-0.25, 0.0, 0.5,  // i0
		1.0, 1.0, 1.0,    // RGB
		0.0, 0.0,         // UV map Bottom left
		0.0f, 1.0f, 0.0f, // normal +Y

		-0.25, 0.0, 0.75, // i1
		1.0, 1.0, 1.0,    // RGB
		0.0, 1.0,		  // UV map Top left
		0.0f, 1.0f, 0.0f, // normal +Y

		0.25, 0.0, 0.5,   // i2
		1.0, 1.0, 1.0,    // RGB
		1.0, 0.0,		  // UV map Bottom right
		0.0f, 1.0f, 0.0f, // normal +Y

		0.25, 0.0, 0.75,  // i3
		1.0, 1.0, 1.0,    // RGB
		1.0, 1.0,		  // UV map Top right
		0.0f, 1.0f, 0.0f  // normal +Y
	};

	// Cylinder Object coords
	GLfloat cylinderVertices[] = {
		0.0, 0.0, 0.0,  // i0
		1.0, 1.0, 1.0,    // RGB
		0.5, 1.0,		  // UV map Top center
		0.0f, 0.0f, 1.0f, // normal +Z

		-0.415, -1.0, 0.0,   // i1
		1.0, 1.0, 1.0,    // RGB
		0.0, 0.0,         // UV map Bottom left
		0.0f, 0.0f, 1.0f, // normal +Z

		0.415, -1.0, 0.0,   // i2
		1.0, 1.0, 1.0,    // RGB
		1.0, 0.0,		  // UV map Bottom right
		0.0f, 0.0f, 1.0f, // normal +Z	
	};

	// Cylinder walls Object coords
	GLfloat cylinderWallVertices[] = {
		-0.5, -1.0, 0.0,  // i0
		1.0, 1.0, 1.0,    // RGB
		0.0, 0.0,         // UV map Bottom left
		0.0f, 0.0f, 1.0f, // normal +Z

		-0.5, 0.0, 0.0,   // i1
		1.0, 1.0, 1.0,    // RGB
		0.0, 1.0,		  // UV map Top left
		0.0f, 0.0f, 1.0f, // normal +Z

		0.5, -1.0, 0.0,   // i2
		1.0, 1.0, 1.0,    // RGB
		1.0, 0.0,		  // UV map Bottom right
		0.0f, 0.0f, 1.0f, // normal +Z

		0.5, 0.0, 0.0,    // i3
		1.0, 1.0, 1.0,    // RGB
		1.0, 1.0,		  // UV map Top right
		0.0f, 0.0f, 1.0f  // normal +Z
	};
	
	// Plane Transforms
	glm::vec3 planePositions[] = {
		glm::vec3(0.0f,  0.0f,  0.5f),
		glm::vec3(0.5f,  0.0f,  0.0f),
		glm::vec3(0.0f,  0.0f,  -0.5f),
		glm::vec3(-0.5f, 0.0f,  0.0f),
		glm::vec3(0.0f, 0.5f,  0.0f),
		glm::vec3(0.0f, -0.5f,  0.0f)
	};

	// Book Positions
	glm::vec3 bookPositions[] = {
		glm::vec3(-0.7f, -0.080f, 0.7f),   
		glm::vec3(-1.2f, -0.080f, 0.2f),   
		glm::vec3(-0.7f, -0.080f, -0.3f),  
		glm::vec3(-0.2f, -0.080f, 0.2f),    
		glm::vec3(-0.7f, 0.420f, 0.2f),    
		glm::vec3(-0.7f, -0.580f, 0.2f)    
	};

	// Plane Transforms
	glm::vec3 tissuePositions[] = {
		glm::vec3(0.7f,  0.0f,  0.5f),   
		glm::vec3(1.2f,  0.0f,  0.0f),   
		glm::vec3(0.7f,  0.0f,  -0.5f),  
		glm::vec3(0.2f, 0.0f,  0.0f),    
		glm::vec3(0.7f, 0.5f,  0.0f),    
		glm::vec3(0.7f, -0.5f,  0.0f)    
	};

	// Cylinder Transforms
	glm::vec3 cylinderPositions[] = {
		glm::vec3(0.2f, 0.25f,  3.0f),
		glm::vec3(0.2f, 0.25f,  3.0f),
		glm::vec3(0.2f, 0.25f,  3.0f),
		glm::vec3(0.2f, 0.25f,  3.0f),
		glm::vec3(0.2f, 0.25f,  3.0f),
		glm::vec3(0.2f, 0.25f,  3.0f),
		glm::vec3(0.2f, 0.25f,  3.0f),
		glm::vec3(0.2f, 0.25f,  3.0f)
	};

	// Cylinder wall Transforms
	glm::vec3 cylinderWallPositions[] = {
		glm::vec3(0.541f, 0.3f, 4.8f),
		glm::vec3(0.541f, 0.3f, 2.4f),
		glm::vec3(0.541f, 1.5f, 3.6f),
		glm::vec3(0.541f, -0.9f, 3.6f),

		glm::vec3(0.541f, 1.15f, 4.45f),
		glm::vec3(0.541f, -0.55f, 2.75f),
		glm::vec3(0.541f, 1.15f, 2.75f),
		glm::vec3(0.541f, -0.55f, 4.45f)

	};

	// 2nd Cylinder WallTransforms
	glm::vec3 chapstickWallPositions[] = {
		glm::vec3(0.0f, 0.0f, 1.205f),
		glm::vec3(0.0f, 0.0f, -1.205f),
		glm::vec3(1.205f, 0.0f, 0.0f),
		glm::vec3(-1.205f, 0.0f, 0.0f),

		glm::vec3(-0.85f, 0.0f, 0.85f),
		glm::vec3(-0.85f, 0.0f, -0.85f),
		glm::vec3(0.85f, 0.0f, 0.85f),
		glm::vec3(0.85f, 0.0f, -0.85f)

	};

	// Object rotation lists
	glm::float32 planeRotations[] = {
		0.0f, 90.0f, 180.0f, -90.0f, -90.f, 90.f
	};

	glm::float32 bookRotations[] = {
		0.0f, -90.0f, -180.0f, 90.0f, -90.f, 90.f
	};

	glm::float32 cylinderRotations[] = {
		0.0f, 45.0f, 90.0f, 135.0f, 180.0f, 225.0f, 270.0f, 315.0f
	};
	

	// Setup some OpenGL options
	glEnable(GL_DEPTH_TEST);

	GLuint tissueVBO, tissueEBO, tissueVAO, tissueBoxVBO, tissueBoxEBO, tissueBoxVAO,
		tableVBO, tableEBO, tableVAO, lampVBO, lampEBO, lampVAO,
		bookVBO, bookEBO, bookVAO, cylinderVBO, cylinderEBO, cylinderVAO, cylinderWallVBO, cylinderWallEBO, cylinderWallVAO;
	
	// Create VBO(s)
	glGenBuffers(1, &lampVBO); 
	glGenBuffers(1, &tissueVBO);
	glGenBuffers(1, &tableVBO);
	glGenBuffers(1, &tissueBoxVBO);
	glGenBuffers(1, &bookVBO);
	glGenBuffers(1, &cylinderVBO);
	glGenBuffers(1, &cylinderWallVBO);

	// Create EBO(s)
	glGenBuffers(1, &lampEBO); 
	glGenBuffers(1, &tissueEBO);
	glGenBuffers(1, &tableEBO);
	glGenBuffers(1, &tissueBoxEBO); 
	glGenBuffers(1, &bookEBO);
	glGenBuffers(1, &cylinderEBO);
	glGenBuffers(1, &cylinderWallEBO);

	// Create VAO(s)
	glGenVertexArrays(1, &lampVAO);
	glGenVertexArrays(1, &tissueVAO); 
	glGenVertexArrays(1, &tableVAO); 
	glGenVertexArrays(1, &tissueBoxVAO);
	glGenVertexArrays(1, &bookVAO);
	glGenVertexArrays(1, &cylinderVAO);
	glGenVertexArrays(1, &cylinderWallVAO);

	// Lamp
	glBindVertexArray(lampVAO);

		// VBO and EBO Placed in User-Defined VAO
		glBindBuffer(GL_ARRAY_BUFFER, lampVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, lampEBO); // Select EBO

		glBufferData(GL_ARRAY_BUFFER, sizeof(lampVertices), lampVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

		// Specify attribute location and layout to GPU
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);

	glBindVertexArray(0); // Unbind VAO or close off (Must call VAO explicitly in loop)

	// Book
	glBindVertexArray(bookVAO); 

		// VBO and EBO Placed in User-Defined VAO
		glBindBuffer(GL_ARRAY_BUFFER, bookVBO); // Select VBO 
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bookEBO); // Select EBO 

		glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

		// Specify attribute location and layout to GPU
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Object coordinates attribute
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));  // Object color attribute
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));  // Object Texture coordinates attribute
		glEnableVertexAttribArray(2);

		glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
		glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VAO or close off (Must call VAO explicitly in loop)

	// Tissue Box
	glBindVertexArray(tissueBoxVAO);

		// VBO and EBO Placed in User-Defined VAO
		glBindBuffer(GL_ARRAY_BUFFER, tissueBoxVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, tissueBoxEBO); // Select EBO

		glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

		// Specify attribute location and layout to GPU
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Object coordinates attribute
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));  // Object color attribute
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));  // Object Texture coordinates attribute
		glEnableVertexAttribArray(2);

		glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
		glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VAO or close off (Must call VAO explicitly in loop)

	// Tissue
	glBindVertexArray(tissueVAO);

		// VBO and EBO Placed in User-Defined VAO
		glBindBuffer(GL_ARRAY_BUFFER, tissueVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, tissueEBO); // Select EBO

		glBufferData(GL_ARRAY_BUFFER, sizeof(tissueVertices), tissueVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

		// Specify attribute location and layout to GPU
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
		glEnableVertexAttribArray(2);

		glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
		glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VAO or close off (Must call VAO explicitly in loop)

	// Cylinder
	glBindVertexArray(cylinderVAO);

		// VBO and EBO Placed in User-Defined VAO
		glBindBuffer(GL_ARRAY_BUFFER, cylinderVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cylinderEBO); // Select EBO

		glBufferData(GL_ARRAY_BUFFER, sizeof(cylinderVertices), cylinderVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW); // Load indices 

		// Specify attribute location and layout to GPU
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
		glEnableVertexAttribArray(2);

		glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
		glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VAO or close off (Must call VAO explicitly in loop)

	// CylinderWall
	glBindVertexArray(cylinderWallVAO);

		// VBO and EBO Placed in User-Defined VAO
		glBindBuffer(GL_ARRAY_BUFFER, cylinderWallVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cylinderWallEBO); // Select EBO

		glBufferData(GL_ARRAY_BUFFER, sizeof(cylinderWallVertices), cylinderWallVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

		// Specify attribute location and layout to GPU
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
		glEnableVertexAttribArray(2);

		glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
		glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VAO or close off (Must call VAO explicitly in loop)

	// Floor Plane
	glBindVertexArray(tableVAO);

		glBindBuffer(GL_ARRAY_BUFFER, tableVBO); // Select VBO
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, tableEBO); // Select EBO

		glBufferData(GL_ARRAY_BUFFER, sizeof(tableVertices), tableVertices, GL_STATIC_DRAW); // Load vertex attributes
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); // Load indices 

		// Specify attribute location and layout to GPU
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
		glEnableVertexAttribArray(2);

		glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat)));
		glEnableVertexAttribArray(3);

	glBindVertexArray(0); // Unbind VAO or close off (Must call VAO explicitly in loop)

	// Load Textures
	int tableTexWidth, tableTexHeight, tissueTexWidth, tissueTexHeight, tissueBoxTexWidth, tissueBoxTexHeight, 
		leatherTexWidth, leatherTexHeight, speakerTexWidth, speakerTexHeight;

	unsigned char* tableImage = SOIL_load_image("Tabletop.png", &tableTexWidth, &tableTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* tissueBoxImage = SOIL_load_image("TissueBox.png", &tissueBoxTexWidth, &tissueBoxTexHeight, 0, SOIL_LOAD_RGBA);
	unsigned char* tissueImage = SOIL_load_image("Tissue.png", &tissueTexWidth, &tissueTexHeight, 0, SOIL_LOAD_RGB);
	unsigned char* leatherImage = SOIL_load_image("Leather.png", &leatherTexWidth, &leatherTexHeight, 0, SOIL_LOAD_RGBA);
	unsigned char* speakerImage = SOIL_load_image("Speaker.jpg", &speakerTexWidth, &speakerTexHeight, 0, SOIL_LOAD_RGBA);

	// Generate Textures
	GLuint tableTexture;
	glGenTextures(1, &tableTexture);
	glBindTexture(GL_TEXTURE_2D, tableTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tableTexWidth, tableTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, tableImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(tableImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint tissueBoxTexture;
	glGenTextures(1, &tissueBoxTexture);
	glBindTexture(GL_TEXTURE_2D, tissueBoxTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tissueBoxTexWidth, tissueBoxTexHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, tissueBoxImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(tissueBoxImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint tissueTexture;
	glGenTextures(1, &tissueTexture);
	glBindTexture(GL_TEXTURE_2D, tissueTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tissueTexWidth, tissueTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, tissueImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(tissueImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint leatherTexture;
	glGenTextures(1, &leatherTexture);
	glBindTexture(GL_TEXTURE_2D, leatherTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, leatherTexWidth, leatherTexHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, leatherImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(leatherImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	GLuint speakerTexture;
	glGenTextures(1, &speakerTexture);
	glBindTexture(GL_TEXTURE_2D, speakerTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, speakerTexWidth, speakerTexHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, speakerImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(speakerImage);
	glBindTexture(GL_TEXTURE_2D, 0);


	// Vertex shader source code
	string vertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;"
		"layout(location = 1) in vec3 aColor;"
		"layout(location = 2) in vec2 texCoord;"
		"layout(location = 3) in vec3 normal;"
		"out vec3 oColor;"
		"out vec2 oTexCoord;"
		"out vec3 oNormal;"
		"out vec3 fragPos;"
		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"
		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		"oColor = aColor;"
		"oTexCoord = texCoord;"
		"oNormal = mat3(transpose(inverse(model))) * normal;"
		"fragPos = vec3(model * vec4(vPosition, 1.0f));"
		"}\n";

	// Fragment shader source code. All commented code is for the second light source in case it is implemented later.
	string fragmentShaderSource =
		"#version 330 core\n"
		"in vec3 oColor;"
		"in vec2 oTexCoord;"
		"in vec3 oNormal;"
		"in vec3 fragPos;"
		"out vec4 fragColor;"
		"uniform sampler2D myTexture;"
		"uniform vec3 objectColor;"
		"uniform vec3 lightColor;"
		"uniform vec3 lightColor2;"
		"uniform vec3 lightPos;"
		"uniform vec3 lightPos2;"
		"uniform vec3 viewPos;"
		"void main()\n"
		"{\n"
		"// Ambient Light\n"
		"float ambientStrength = 0.2f;"
		"vec3 ambient = ambientStrength * lightColor;"
		"float ambientStrength2 = 0.3f;"
		"vec3 ambient2 = ambientStrength2 * lightColor2;"
		"// Diffuse Light\n"
		"vec3 norm = normalize(oNormal);"
		"vec3 lightDir = normalize(lightPos - fragPos);"
		"float diff = max(dot(norm, lightDir), 0.0);"
		"vec3 diffuse = diff * lightColor;"
		"vec3 lightDir2 = normalize(lightPos2 - fragPos);"
		"float diff2 = max(dot(norm, lightDir2), 0.0);"
		"vec3 diffuse2 = diff2 * lightColor2;"
		"// Specular Light\n"
		"float specularStrength = 1.0f;"
		"vec3 viewDir = normalize(viewPos - fragPos);"
		"vec3 reflectDir = reflect(-lightDir, norm);"
		"float spec = pow(max(dot(viewDir, reflectDir), 0.0), 128);"
		"vec3 specular = specularStrength * spec * lightColor;"
		"float specularStrength2 = 1.0f;"
		"vec3 reflectDir2 = reflect(-lightDir2, norm);"
		"float spec2 = pow(max(dot(viewDir, reflectDir2), 0.0), 128);"
		"vec3 specular2 = specularStrength2 * spec2 * lightColor2;"
		"vec3 result = (ambient + diffuse + specular);"
		"result += (ambient2 + diffuse2 + specular2);"
		"fragColor = texture(myTexture, oTexCoord) * vec4(result, 1.0f);"
		"}\n";

	// Lamp Vertex shader source code
	string lampVertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;"
		"uniform mat4 model;"
		"uniform mat4 view;"
		"uniform mat4 projection;"
		"void main()\n"
		"{\n"
		"gl_Position = projection * view * model * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		"}\n";

	// Lamp Fragment shader source code
	string lampFragmentShaderSource =
		"#version 330 core\n"
		"out vec4 fragColor;"
		"void main()\n"
		"{\n"
		"fragColor = vec4(1.0f);"
		"}\n";

	// Creating Shader Program
	GLuint shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);
	GLuint lampShaderProgram = CreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource);

	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		// Set deltaTime
		GLfloat currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// Read input
		processInput(window);

		// Togglable wireframe mode
		if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS) {
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		}
		if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS) {
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		}

		// Resize window and graphics simultaneously
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);

		/* Render here */
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Use Shader Program exe and select VAO before drawing 
		glUseProgram(shaderProgram); // Call Shader per-frame when updating attributes

		// Declare transformations (can be initialized outside loop)
		glm::mat4 projectionMatrix;
		viewMatrix = glm::lookAt(cameraPosition, getTarget(), worldUp);

		// Switch between Orthographic 2D view and Perspective 3D view on key press P
		if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
			projectionMatrix = glm::ortho(-3.0f, 3.0f, -3.0f, 3.0f, 0.1f, 100.0f);
		else
			projectionMatrix = glm::perspective(fov, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);

		// Get matrix's uniform location and set matrix
		GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
		GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
		GLint projLoc = glGetUniformLocation(shaderProgram, "projection");

		// Get light color location, object color location and light position
		GLint objectColorLoc = glGetUniformLocation(shaderProgram, "objectColor");
		GLint lightColorLoc = glGetUniformLocation(shaderProgram, "lightColor");
		GLint lightColorLoc2 = glGetUniformLocation(shaderProgram, "lightColor2");
		GLint lightPosLoc = glGetUniformLocation(shaderProgram, "lightPos");
		GLint lightPosLoc2 = glGetUniformLocation(shaderProgram, "lightPos2");
		GLint viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");

		// Assign object and light Colors
		glUniform3f(objectColorLoc, 0.23f, 0.71f, 0.94f); // Sample color for tissue box
		glUniform3f(lightColorLoc, lightR, lightG, lightB); // color changing light
		glUniform3f(lightColorLoc2, 0.99f, 0.93f, 0.68f); // Yellow  candle light

		// Assign light position
		glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);
		glUniform3f(lightPosLoc2, lightPosition2.x, lightPosition2.y, lightPosition2.z);

		// Specify view position
		glUniform3f(viewPosLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

		// Draw Table Object and apply transforms
		glBindTexture(GL_TEXTURE_2D, tableTexture);
		glBindVertexArray(tableVAO); // User-defined VAO must be called before draw.
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(1.0f, 1.0f, 1.0f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, -0.2f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, 270.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw();
		glBindVertexArray(0); //Incase different VAO will be used after

		// Draw Book Object and apply transforms
		glBindTexture(GL_TEXTURE_2D, leatherTexture);
		glBindVertexArray(bookVAO); // User-defined VAO must be called before draw. 
		for (GLuint i = 0; i < 6; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(1.0f, 0.3f, 1.5f)); 
			modelMatrix = glm::translate(modelMatrix, bookPositions[i]); 
			modelMatrix = glm::rotate(modelMatrix, bookRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f)); 
			if (i >= 4) {
				modelMatrix = glm::rotate(modelMatrix, bookRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f)); 
			}
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw();
		}
		glBindVertexArray(0); //Incase different VAO will be used after

		// Draw TissueBox Object and apply transforms
		glBindTexture(GL_TEXTURE_2D, tissueBoxTexture);
		glBindVertexArray(tissueBoxVAO); // User-defined VAO must be called before draw. 
		for (GLuint i = 0; i < 6; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(1.3f, 0.4f, 1.0f));
			modelMatrix = glm::translate(modelMatrix, tissuePositions[i]);
			modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			if (i >= 4) {
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw();
		}
		glBindVertexArray(0); //Incase different VAO will be used after

		// Draw Tissue Object and apply transforms
		glBindTexture(GL_TEXTURE_2D, tissueTexture);
		glBindVertexArray(tissueVAO); // User-defined VAO must be called before draw. 
			modelMatrix = glm::scale(modelMatrix, glm::vec3(1.4f, 1.1f, 1.0f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0.65f, 0.0f, 1.15f));
			modelMatrix = glm::rotate(modelMatrix, 180.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw();
		glBindVertexArray(0); //Incase different VAO will be used after

		// Draw Speaker Ends and apply transforms
		glBindTexture(GL_TEXTURE_2D, speakerTexture);
		glBindVertexArray(cylinderVAO); // User-defined VAO must be called before draw. 
		for (GLuint i = 0; i < 8; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.3f, 0.3f, 0.3f));
			modelMatrix = glm::translate(modelMatrix, cylinderPositions[i]);
			modelMatrix = glm::rotate(modelMatrix, cylinderRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, 90.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw2();
		}
		for (GLuint i = 0; i < 8; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.3f, 0.3f, 0.3f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(5.03f, 0.25f, 3.0f));
			modelMatrix = glm::rotate(modelMatrix, cylinderRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, 90.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw2();
		}
		glBindVertexArray(0); //Incase different VAO will be used after

		// Draw Speaker Sides and apply transforms
		glBindVertexArray(tissueBoxVAO); // User-defined VAO must be called before draw. 
		for (GLuint i = 0; i < 8; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(1.45f, 0.25f, 0.25f));
			modelMatrix = glm::translate(modelMatrix, cylinderWallPositions[i]);
			// If statements to determine rotations for that side. Switch case was not working right.
			if (i == 1) {
				modelMatrix = glm::rotate(modelMatrix, 180.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			if (i == 2) {
				modelMatrix = glm::rotate(modelMatrix, -180.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			if (i == 2) {
				modelMatrix = glm::rotate(modelMatrix, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			if (i == 3) {
				modelMatrix = glm::rotate(modelMatrix, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			if (i == 4) {
				modelMatrix = glm::rotate(modelMatrix, -45.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			if (i == 5) {
				modelMatrix = glm::rotate(modelMatrix, 135.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			if (i == 6) {
				modelMatrix = glm::rotate(modelMatrix, -135.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			if (i == 7) {
				modelMatrix = glm::rotate(modelMatrix, 45.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
			}
			
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw();
		}
		glBindVertexArray(0); //Incase different VAO will be used after

		// Draw Chapstick
		glBindTexture(GL_TEXTURE_2D, tissueTexture);
		glBindVertexArray(cylinderVAO); // User-defined VAO must be called before draw. 
		for (GLuint i = 0; i < 8; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.1f, 0.1f, 0.1f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-6.0f, -1.9f, 13.0f));
			modelMatrix = glm::rotate(modelMatrix, cylinderRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, .0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw2();
		}
		for (GLuint i = 0; i < 8; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.1f, 0.1f, 0.1f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-6.0f, 3.18f, 13.0f));
			modelMatrix = glm::rotate(modelMatrix, cylinderRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			modelMatrix = glm::rotate(modelMatrix, 270.0f * toRadians, glm::vec3(1.0f, 0.0f, .0f));
			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw2();
		}
		glBindVertexArray(0); //Incase different VAO will be used after

		// Draw Chapstick Sides and apply transforms
		glBindVertexArray(tissueBoxVAO); // User-defined VAO must be called before draw. 
		for (GLuint i = 0; i < 8; i++) {
			glm::mat4 modelMatrix;
			modelMatrix = glm::scale(modelMatrix, glm::vec3(0.0819f, 0.505f, 0.0819f));
			modelMatrix = glm::translate(modelMatrix, chapstickWallPositions[i]); 
			modelMatrix = glm::translate(modelMatrix, glm::vec3(-7.35f, 0.13f, 15.9f));
			// If statements to determine rotations for that side. Switch case was not working right.
			if (i == 1) {
				modelMatrix = glm::rotate(modelMatrix, 180.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			}
			if (i == 2) {
				modelMatrix = glm::rotate(modelMatrix, 90.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			}
			if (i == 3) {
				modelMatrix = glm::rotate(modelMatrix, -90.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			}
			if (i == 4) {
				modelMatrix = glm::rotate(modelMatrix, -45.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			}
			if (i == 5) {
				modelMatrix = glm::rotate(modelMatrix, 225.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			}
			if (i == 6) {
				modelMatrix = glm::rotate(modelMatrix, 45.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			}
			if (i == 7) {
				modelMatrix = glm::rotate(modelMatrix, 135.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
			}

			glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
			draw();
		}
		glBindVertexArray(0); //Incase different VAO will be used after

		glUseProgram(0); // Incase different shader will be used after

		// Using lamp shader
		glUseProgram(lampShaderProgram);

			// Select shader and uniform variable
			GLint lampModelLoc = glGetUniformLocation(lampShaderProgram, "model");
			GLint lampViewLoc = glGetUniformLocation(lampShaderProgram, "view");
			GLint lampProjectionLoc = glGetUniformLocation(lampShaderProgram, "projection");

			// Pass transforms to the shader
			glUniformMatrix4fv(lampViewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));
			glUniformMatrix4fv(lampProjectionLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

			// Draw lamp and apply transforms
			glBindVertexArray(lampVAO);
			for (GLuint i = 0; i < 6; i++) {
				glm::mat4 modelMatrix;
				modelMatrix = glm::translate(modelMatrix, planePositions[i] / glm::vec3(8.0f, 8.0f, 8.0f) + lightPosition);
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.125f, 0.125f, 0.125f));
				if (i >= 4) {
					modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
				}
				glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
				draw();
			}
			glBindVertexArray(0);
			// Second Light
			glBindVertexArray(lampVAO);
			for (GLuint i = 0; i < 6; i++) {
				glm::mat4 modelMatrix;
				modelMatrix = glm::translate(modelMatrix, planePositions[i] / glm::vec3(8.0f, 8.0f, 8.0f) + lightPosition2);
				modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.125f, 0.125f, 0.125f));
				if (i >= 4) {
					modelMatrix = glm::rotate(modelMatrix, planeRotations[i] * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
				}
				glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
				draw();
			}
			glBindVertexArray(0);

		glUseProgram(0); // Incase different shader will be used after

		/* Swap front and back buffers */
		glfwSwapBuffers(window);
		/* Poll for and process events */
		glfwPollEvents();
		// Poll camera transformations
		transformCamera();
	}

	//Clear GPU resources
	glDeleteVertexArrays(1, &tissueVAO);
	glDeleteBuffers(1, &tissueVBO);
	glDeleteBuffers(1, &tissueEBO);

	glfwTerminate();
	return 0;
}

// Define input callback functions
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	// Display ASCII keycode
	//cout << "ASCII: " << key << endl;

	// Assign pressed keys a boolean value
	if (action == GLFW_PRESS)
		keys[key] = true;
	else if (action == GLFW_RELEASE)
		keys[key] = false;
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
	/*
	// Display scroll offset
	if (yoffset > 0)
		cout << "Scroll Up: ";
	if (yoffset < 0)
		cout << "Scroll Down: ";

	cout << yoffset << endl;
	*/

	// Clamp FOV
	if (fov >= 1.f && fov <= 55.f)
		fov -= yoffset * 0.02f;

	// Default FOV
	if (fov < 1.f)
		fov = 1.f;
	if (fov > 45.f)
		fov = 45.f;
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
	/*
	// Detect mouse button click
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
		cout << "Left Click" << endl;
	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
		cout << "Right Click" << endl;
	if (button == GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW_PRESS)
		cout << "Middle Click" << endl;
		*/

	if (action == GLFW_PRESS)
		mouseButtons[button] = true;
	else if (action == GLFW_RELEASE)
		mouseButtons[button] = false;
}

void cursor_position_callback(GLFWwindow* window, double xpos, double ypos) {
	// Display cursor position
	//cout << "Mouse X Pos: " << xpos << endl;
	//cout << "Mouse Y Pos: " << ypos << endl;

	if (firstMouseMove) {
		lastX = xpos;
		lastY = ypos;
		firstMouseMove = false;
	}

	// Calculate cursor offset
	xChange = xpos - lastX;
	yChange = lastY - ypos;

	lastX = xpos;
	lastY = ypos;

	// Panning Camera
	if (isPanning) {

		if (cameraPosition.z < 0.f)
			cameraFront.z = 1.f;
		else
			cameraFront.z = -1.f;

		GLfloat cameraSpeed = xChange * deltaTime;
		cameraPosition += cameraSpeed * cameraRight;

		cameraSpeed = yChange * deltaTime;
		cameraPosition += cameraSpeed * cameraUp;
	}

	// Orbit camera
	if (isOrbiting) {
		rawYaw += xChange;
		rawPitch += yChange;

		// Convert yaw and ptich to degrees
		degYaw = glm::radians(rawYaw);
		//degPitch = glm::radians(rawPitch);
		degPitch = glm::clamp(glm::radians(rawPitch), -glm::pi<float>() / 2.f + .1f, glm::pi<float>() / 2.f - .1f);

		// Azimuth altitude formula
		cameraPosition.x = cameraTarget.x + radius * cosf(degPitch) * sinf(degYaw);
		cameraPosition.y = cameraTarget.y + radius * sinf(degPitch);
		cameraPosition.z = cameraTarget.z + radius * cosf(degPitch) * cosf(degYaw);
	}
}

// Define getTarget function
glm::vec3 getTarget() {
	if (isPanning)
		cameraTarget = cameraPosition + cameraFront;

	return cameraTarget;
}

// Define transformCamera function
void transformCamera() {
	// pan camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_MIDDLE])
		isPanning = true;
	else
		isPanning = false;

	// Orbit camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_LEFT])
		isOrbiting = true;
	else
		isOrbiting = false;

	// Reset Camera
	if (keys[GLFW_KEY_F])
		initCamera();
}


// Initial Camera placement
void initCamera() {
	cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f);
	cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f);
	cameraDirection = glm::normalize(cameraPosition - cameraTarget);
	worldUp = glm::vec3(0.0f, 1.f, 0.0f);
	cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));
	cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight));
	cameraFront = glm::normalize(glm::vec3(0.0f, 0.0f, -1.0f));
}

// WASD control and other inputs
void processInput(GLFWwindow* window)
{
	// Window Close
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	// WASD movement
	float cameraSpeed = 2.5 * deltaTime;
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPosition += cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPosition -= cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPosition -= cameraSpeed * cameraRight;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPosition += cameraSpeed * cameraRight;

	// QE movement
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		cameraPosition += cameraSpeed * cameraUp;
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		cameraPosition -= cameraSpeed * cameraUp;
	
	// Color lights!!!
	if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS) {
		lightR = 1.0f;
		lightG = 0.0f;
		lightB = 0.0f;
	}
	if (glfwGetKey(window, GLFW_KEY_G) == GLFW_PRESS) {
		lightR = 0.0f;
		lightG = 1.0f;
		lightB = 0.0f;
	}
	if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS) {
		lightR = 0.0f;
		lightG = 0.0f;
		lightB = 1.0f;
	}
	
	// Reset color lights
	if (keys[GLFW_KEY_R] && keys[GLFW_KEY_LEFT_SHIFT]) {
		lightR = 1.0f;
		lightG = 1.0f;
		lightB = 1.0f;
	}

}
